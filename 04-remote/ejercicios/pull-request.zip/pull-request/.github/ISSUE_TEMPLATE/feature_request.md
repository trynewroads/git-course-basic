---
name: Nueva Funcionalidad
about: Proponer una nueva funcionalidad para implementar
title: '[FEATURE] '
labels: 'feature, help wanted'
assignees: ''
---

## 🎯 Funcionalidad a implementar
<!-- Describe clara y brevemente la funcionalidad -->

## 📋 Descripción detallada
<!-- Explica en detalle qué debe hacer esta funcionalidad -->

## 🎨 Diseño/Mockup
<!-- Si tienes una idea visual, compártela aquí -->

## ⚡ Tareas técnicas
<!-- Lista de tareas específicas a realizar -->
- [ ] Crear estructura HTML
- [ ] Implementar estilos CSS
- [ ] Agregar funcionalidad JavaScript
- [ ] Hacer responsive design
- [ ] Probar en diferentes navegadores
- [ ] Documentar el código

## 📐 Criterios de aceptación
<!-- ¿Cómo sabemos que está terminado? -->
- [ ] La funcionalidad es visualmente atractiva
- [ ] Funciona correctamente en escritorio y móvil
- [ ] No rompe la funcionalidad existente
- [ ] El código está limpio y comentado
- [ ] Sigue las convenciones del proyecto
- [ ] Se probó en al menos 2 navegadores

## 🔧 Nivel de dificultad
<!-- Marca el nivel apropiado -->
- [ ] 🟢 Principiante (HTML/CSS básico)
- [ ] 🟡 Intermedio (JavaScript, interacciones)
- [ ] 🔴 Avanzado (funcionalidad compleja)

## 💡 Recursos útiles
<!-- Links, tutoriales, o ejemplos que pueden ayudar -->

## 👥 Equipo sugerido
<!-- Número recomendado de personas para esta tarea -->
**Tamaño del equipo:** 2-3 personas
**Tiempo estimado:** X horas

## 🎨 Consideraciones de diseño
<!-- Aspectos visuales a tener en cuenta -->
- [ ] Seguir la paleta de colores existente (CSS variables)
- [ ] Mantener consistencia tipográfica
- [ ] Considerar responsive design desde el inicio
- [ ] Usar las clases utilitarias disponibles

## 🔗 Archivos a modificar (probablemente)
<!-- Archivos que este issue probablemente afectará -->
- [ ] `index.html`
- [ ] `css/styles.css`
- [ ] `js/main.js`
- [ ] Otros: ___________

## 📝 Notas adicionales
<!-- Cualquier información extra que pueda ser útil -->

---
**Para comenzar:**
1. Asignarse el issue
2. Hacer fork del repositorio
3. Crear rama: `git checkout -b feature/nombre-funcionalidad`
4. ¡Comenzar a desarrollar! 🚀