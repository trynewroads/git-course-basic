## 📝 Descripción
<!-- Describe brevemente qué funcionalidad implementa este PR -->

## ✨ Cambios realizados
<!-- Marca las tareas completadas -->
- [ ] Implementación de la funcionalidad principal
- [ ] Estilos CSS agregados/modificados
- [ ] JavaScript funcional agregado
- [ ] Archivos de assets (imágenes, iconos, etc.)
- [ ] Documentación actualizada

## 🎯 Issue relacionado
<!-- Menciona el issue que este PR resuelve -->
Closes #

## 🧪 ¿Cómo probarlo?
<!-- Describe los pasos para probar la funcionalidad -->
1. Abrir `index.html` en el navegador
2. Navegar a la sección implementada
3. Probar la funcionalidad:
   - [ ] La sección se muestra correctamente
   - [ ] Los estilos se aplican bien
   - [ ] El JavaScript funciona sin errores en consola
   - [ ] Es responsive (se ve bien en móvil)

## 👥 Equipo colaborador
<!-- Menciona a los miembros del equipo -->
- @usuario1 - Rol/Responsabilidad
- @usuario2 - Rol/Responsabilidad
- @usuario3 - Rol/Responsabilidad

## 📸 Screenshots
<!-- Agregar capturas de pantalla de los cambios visuales -->

**Antes:**
<!-- Screenshot del estado anterior (si aplica) -->

**Después:**
<!-- Screenshot del resultado final -->

## ✅ Checklist del equipo
- [ ] El código funciona correctamente
- [ ] Se probó en diferentes navegadores (Chrome, Firefox)
- [ ] Se probó en dispositivos móviles
- [ ] No hay errores en la consola del navegador
- [ ] El código está limpio y comentado
- [ ] Se siguieron las convenciones de nomenclatura
- [ ] No se rompió funcionalidad existente
- [ ] Se actualizó documentación si es necesario

## 🎨 Aspectos de diseño
- [ ] El diseño es consistente con el resto del sitio
- [ ] Los colores siguen la paleta establecida (CSS variables)
- [ ] La tipografía es coherente
- [ ] El spacing y layout se ven bien
- [ ] Las animaciones son suaves y no distraen

## 🔧 Aspectos técnicos
- [ ] El código sigue las convenciones del proyecto
- [ ] Las funciones están bien documentadas
- [ ] Se utilizaron las clases CSS existentes cuando fue posible
- [ ] Se siguió la estructura de carpetas establecida
- [ ] Los nombres de archivos/funciones son descriptivos

## 💭 Notas para el reviewer
<!-- Información específica que el reviewer debe considerar -->
- ¿Hay alguna parte del código que necesita atención especial?
- ¿Se implementaron patrones específicos que deben validarse?
- ¿Hay dependencias externas nuevas?

## 🚀 Próximos pasos (opcional)
<!-- Si este PR es parte de una funcionalidad más grande -->
- [ ] Paso siguiente 1
- [ ] Paso siguiente 2

---
**¡Gracias por contribuir al proyecto! 🎉**

**Para reviewers:** 
- [ ] ✅ Apruebo los cambios
- [ ] 🔄 Solicito cambios
- [ ] 💬 Comentarios adicionales