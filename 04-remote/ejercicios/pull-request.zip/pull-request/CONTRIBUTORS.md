# Colaboradores del Proyecto 👥

Este archivo será actualizado automáticamente cuando los equipos completen sus Pull Requests.

## 📊 Estadísticas del Proyecto

- **Issues Totales**: 6
- **Issues Completados**: 0
- **Pull Requests Merged**: 0
- **Colaboradores Activos**: 0
- **Líneas de Código**: ~1000

## 🏆 Equipos y Progreso

| Equipo | Issue Asignado | Estado | Miembros | PR Link |
|--------|----------------|--------|----------|---------|
| Team 1 | Navegación | ⏳ Pendiente | - | - |
| Team 2 | Características | ⏳ Pendiente | - | - |
| Team 3 | Contacto | ⏳ Pendiente | - | - |
| Team 4 | Galería | ⏳ Pendiente | - | - |
| Team 5 | Testimonios | ⏳ Pendiente | - | - |
| Team 6 | Footer | ⏳ Pendiente | - | - |

## ✅ Funcionalidades Implementadas

_Esta sección se actualizará conforme se mergeen los Pull Requests_

---

## 🎯 Para nuevos colaboradores

### Pasos para contribuir:
1. **Fork** este repositorio
2. **Clone** tu fork localmente
3. **Crea** una rama: `git checkout -b feature/tu-funcionalidad`
4. **Implementa** tu funcionalidad
5. **Push** y crea un **Pull Request**

### Convenciones:
- Nombres de ramas: `feature/nombre-descriptivo`
- Commits descriptivos en español
- Usar el template de PR
- Probar en mobile y desktop

---
*Última actualización: Proyecto iniciado*