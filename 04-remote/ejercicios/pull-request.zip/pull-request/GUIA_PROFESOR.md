# 📚 GUÍA PARA EL PROFESOR - Ejercicio Pull Requests

## 🚀 Setup inicial del ejercicio

### 1. Preparar el repositorio base
```bash
# Descomprimir el archivo proporcionado
unzip pull-request.zip
cd pull-request

# Verificar que todo está listo
git log --oneline  # Debería mostrar ~8 commits con historial completo
ls -la  # Verificar todos los archivos incluidos

# El repositorio ya viene inicializado con:
# - Estructura HTML, CSS, JavaScript completa
# - Templates de GitHub para PR e Issues
# - Documentación completa
# - Historial de commits realista
```

### 2. Subir a tu GitHub
```bash
# Cambiar el remoto por tu repositorio
git remote add origin git@github.com:TU-USUARIO/ejercicio-pull-requests.git
git branch -M main
git push -u origin main
```

> ⚡ **Ventaja**: El repositorio ya viene con historial completo y se ve profesional desde el primer momento.

### 2. Configurar el repositorio en GitHub
1. **Settings → General**:
   - Habilitar "Issues"
   - Habilitar "Pull Requests"
   
2. **Settings → Branches**:
   - Proteger rama `main`
   - Requerir Pull Request reviews
   - Requerir que las ramas estén actualizadas

3. **Issues → New Issue**:
   - Crear issues usando las plantillas disponibles
   - Ver sección "Issues sugeridos" más abajo

### 3. ¿Qué viene incluido en el ZIP?
El archivo `pull-request.zip` incluye:
- ✅ **Proyecto web base** con HTML, CSS y JavaScript funcional
- ✅ **Repositorio Git** con historial de commits realista (~8 commits)
- ✅ **Templates de GitHub** para Pull Requests e Issues
- ✅ **Documentación completa** (README, CHANGELOG, LICENSE)
- ✅ **Guías para estudiantes** y estructura de carpetas
- ✅ **Estilos modernos** con sistema de diseño CSS
- ✅ **Funciones JavaScript** utilitarias para los equipos

> 🎯 **Listo para usar**: Solo descomprimir, subir a GitHub y crear los Issues.

## 📋 Issues sugeridos para crear

### Issue 1: Navegación
```
Título: [NAVEGACIÓN] Implementar menú de navegación responsive
Descripción: Usar la plantilla navegacion.md
Labels: feature, frontend, html, css
Assignees: [vacío para que los equipos se auto-asignen]
```

### Issue 2: Sección de Características
```
Título: [FEATURES] Crear sección de características con tarjetas
Descripción: 
- Mostrar la sección #features
- Crear 3-4 tarjetas con iconos
- Usar grid CSS para layout responsive
- Añadir efectos hover

Labels: feature, frontend, css
```

### Issue 3: Formulario de Contacto
```
Título: [CONTACTO] Implementar formulario de contacto funcional
Descripción:
- Mostrar sección #contact
- Campos: nombre, email, mensaje
- Validación JavaScript
- Envío simulado (alert de éxito)

Labels: feature, frontend, javascript
```

### Issue 4: Galería de Imágenes
```
Título: [GALERÍA] Crear galería de imágenes con lightbox
Descripción:
- Mostrar sección #gallery
- Grid de 6-8 imágenes placeholder
- Efecto lightbox al hacer click
- Navegación anterior/siguiente

Labels: feature, frontend, javascript
```

### Issue 5: Testimonios
```
Título: [TESTIMONIOS] Slider de testimonios de usuarios
Descripción:
- Mostrar sección #testimonials
- 3-4 testimonios rotativos
- Navegación con dots/flechas
- Auto-play opcional

Labels: feature, frontend, javascript
```

### Issue 6: Footer
```
Título: [FOOTER] Implementar footer completo
Descripción:
- Mostrar footer
- Información de contacto
- Links útiles
- Redes sociales (iconos)
- Copyright actualizable

Labels: feature, frontend, html, css
```

## 👥 Organización de equipos

### Sugerencia: 6 equipos de 2-3 estudiantes
- **Equipo 1**: Navegación (medio)
- **Equipo 2**: Características (fácil)
- **Equipo 3**: Contacto (medio)
- **Equipo 4**: Galería (difícil)
- **Equipo 5**: Testimonios (difícil)
- **Equipo 6**: Footer (fácil)

## 📋 Checklist para el ejercicio

### Preparación (5 minutos):
- [ ] Descomprimir `pull-request.zip`
- [ ] Subir repositorio a tu GitHub
- [ ] Configurar protección de rama `main`
- [ ] Crear issues usando las plantillas
- [ ] Asignar equipos a issues

### Antes de la clase:
- [ ] Repositorio público en GitHub con issues creados
- [ ] Equipos formados (2-3 estudiantes por equipo)
- [ ] Issues asignados a equipos
- [ ] Probar que el HTML se ve correctamente

### Durante la clase (90-120 minutos):
- [ ] **Explicación inicial (15 min)**: Flujo fork → branch → PR
- [ ] **Demo en vivo (10 min)**: Mostrar cómo hacer fork y crear PR
- [ ] **Trabajo en equipos (60-90 min)**: Implementar funcionalidades
- [ ] **Reviews cruzadas (15 min)**: Equipos revisan PRs de otros
- [ ] **Merge y celebración (10 min)**: Aprobar PRs exitosos

### Después de cada PR:
- [ ] Revisar que sigue las convenciones del proyecto
- [ ] Verificar que funciona correctamente (probar HTML)
- [ ] Hacer merge si está aprobado por reviewers
- [ ] Actualizar CONTRIBUTORS.md
- [ ] Celebrar con el equipo 🎉

## 🔧 Comandos útiles para estudiantes

### Comandos para estudiantes (copia y pega):

#### Setup inicial del equipo:
```bash
# 1. Hacer FORK en GitHub (botón Fork en el repositorio del profesor)

# 2. Clonar TU fork (no el del profesor)
git clone git@github.com:TU-USUARIO/ejercicio-pull-requests.git
cd ejercicio-pull-requests

# 3. Configurar upstream para traer cambios del profesor
git remote add upstream git@github.com:PROFESOR/ejercicio-pull-requests.git

# 4. Verificar remotos
git remote -v
# Debería mostrar:
# origin    git@github.com:TU-USUARIO/ejercicio-pull-requests.git
# upstream  git@github.com:PROFESOR/ejercicio-pull-requests.git
```

#### Flujo de desarrollo:
```bash
# 1. Crear rama de feature (usar nombres descriptivos)
git checkout -b feature/navegacion-responsive

# 2. Implementar cambios y hacer commits regulares
git add .
git commit -m "feat: Add responsive navigation HTML structure"

git add .
git commit -m "style: Add navigation CSS with mobile menu"

git add .
git commit -m "feat: Add JavaScript toggle for mobile menu"

# 3. Push de la rama (primera vez con -u)
git push -u origin feature/navegacion-responsive

# 4. Crear Pull Request en GitHub usando el template
```

### Mantener actualizado:
```bash
# Traer cambios del repositorio original
git fetch upstream
git checkout main
git merge upstream/main
git push origin main
```

## 📊 Criterios de evaluación

### Técnico (60%):
- [ ] Funcionalidad implementada correctamente
- [ ] Código limpio y comentado
- [ ] Responsive design
- [ ] Sin errores en consola
- [ ] Seguimiento de convenciones

### Colaboración (40%):
- [ ] Calidad del PR (descripción, screenshots)
- [ ] Participación en reviews
- [ ] Comunicación efectiva
- [ ] Resolución de conflictos
- [ ] Trabajo en equipo

## 🎯 Objetivos de aprendizaje

Al finalizar, los estudiantes habrán:
- ✅ Practicado el flujo completo de Pull Requests
- ✅ Trabajado colaborativamente con Git
- ✅ Resuelto conflictos de merge
- ✅ Revisado código de otros equipos
- ✅ Usado issues y templates de GitHub
- ✅ Implementado funcionalidades web reales

## 🚨 Problemas comunes y soluciones

### "No puedo hacer push"
```bash
git pull upstream main  # Actualizar primero
git push origin feature/mi-rama
```

### "Conflictos en el merge"
```bash
# Resolver conflictos manualmente en los archivos
git add .
git commit -m "Resolver conflictos de merge"
```

### "Mi PR tiene conflictos"
```bash
git fetch upstream
git checkout main
git merge upstream/main
git checkout feature/mi-rama
git rebase main  # o git merge main
```

## 📞 Soporte durante la clase

### Tener preparado:
- [ ] El archivo `pull-request.zip` original como respaldo
- [ ] Ejemplos de conflictos y cómo resolverlos
- [ ] Screenshots del proceso PR en GitHub  
- [ ] Lista de comandos git esenciales impresos
- [ ] URL del repositorio en GitHub anotada

### Para reutilizar en otras clases:
1. **Comprimir para futuro uso**:
   ```bash
   # Después de la clase exitosa
   cd directorio-padre
   zip -r pull-request-v2.zip pull-request/
   ```

2. **Limpiar para nueva clase**:
   ```bash
   # Resetear el repositorio a estado inicial
   cd pull-request
   git reset --hard HEAD~X  # X = número de PRs mergeados
   git push --force-with-lease origin main
   ```

### 🎉 Resultado esperado:
- ✅ 6 funcionalidades implementadas colaborativamente
- ✅ Estudiantes conocen flujo completo de PR
- ✅ Experiencia práctica con revisiones de código
- ✅ Sitio web funcional y atractivo como resultado
- ✅ Estudiantes preparados para contribuir a proyectos open source

---
## 🚀 ¡Listo para una clase colaborativa exitosa!

> **💡 Tip**: Guarda el `pull-request.zip` original. Cada vez que vayas a dar la clase, solo descomprímelo, súbelo a un nuevo repo en GitHub y ¡listos para colaborar!