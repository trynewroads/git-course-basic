# Placeholder para imágenes

Este directorio contendrá las imágenes que los equipos agreguen para sus funcionalidades:

## Imágenes sugeridas por equipo:

### Team 4 - Galería
- `gallery-1.jpg` - Imagen principal
- `gallery-2.jpg` - Imagen secundaria  
- `gallery-3.jpg` - etc.

### Team 5 - Testimonios
- `testimonial-user-1.jpg` - Avatar usuario 1
- `testimonial-user-2.jpg` - Avatar usuario 2

### Team 6 - Footer
- `logo-footer.png` - Logo para footer
- `social-icons/` - Iconos de redes sociales

## Recursos gratuitos recomendados:
- [Unsplash](https://unsplash.com/) - Fotos de alta calidad
- [Pixabay](https://pixabay.com/) - Imágenes y iconos
- [Pexels](https://pexels.com/) - Fotos stock gratuitas

## Formato recomendado:
- Fotos: `.jpg` optimizadas (máx 800px ancho)
- Iconos: `.svg` o `.png` con transparencia
- Logos: `.svg` preferiblemente