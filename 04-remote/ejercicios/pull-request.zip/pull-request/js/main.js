// ============================================
// JAVASCRIPT PRINCIPAL DEL PROYECTO COLABORATIVO
// ============================================

document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 Proyecto colaborativo iniciado');
    console.log('📚 Funciones utilitarias disponibles para los equipos');
    
    // Inicializar funcionalidades básicas
    initializeBasicFeatures();
    
    // Mostrar mensaje de bienvenida
    showWelcomeMessage();
});

// ============================================
// FUNCIONES BÁSICAS Y UTILITARIAS
// ============================================

/**
 * Inicializar características básicas de la página
 */
function initializeBasicFeatures() {
    // Agregar efectos hover a botones existentes
    addButtonEffects();
    
    // Configurar smooth scrolling para enlaces ancla
    setupSmoothScrolling();
    
    // Mostrar información en consola para desarrollo
    showDevelopmentInfo();
}

/**
 * Agregar efectos interactivos a los botones
 */
function addButtonEffects() {
    const buttons = document.querySelectorAll('.btn');
    buttons.forEach(button => {
        button.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-2px)';
        });
        
        button.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
        
        // Efecto de click
        button.addEventListener('click', function(e) {
            // Crear efecto de ripple
            createRippleEffect(e, this);
        });
    });
}

/**
 * Configurar navegación suave entre secciones
 */
function setupSmoothScrolling() {
    // Se aplicará cuando los equipos agreguen navegación
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

/**
 * Mostrar información útil en consola para desarrollo
 */
function showDevelopmentInfo() {
    console.log('=================================');
    console.log('📋 INFORMACIÓN PARA DESARROLLADORES');
    console.log('=================================');
    console.log('🔧 Funciones disponibles:');
    console.log('  - showSection(id): Mostrar sección oculta');
    console.log('  - hideSection(id): Ocultar sección');
    console.log('  - showMessage(text, type): Mostrar mensaje');
    console.log('  - createRippleEffect(event, element): Efecto ripple');
    console.log('  - validateForm(formElement): Validar formulario');
    console.log('=================================');
}

/**
 * Mostrar mensaje de bienvenida
 */
function showWelcomeMessage() {
    setTimeout(() => {
        console.log('👋 ¡Bienvenidos al proyecto colaborativo!');
        console.log('🎯 Los equipos pueden comenzar a implementar sus funcionalidades');
    }, 1000);
}

// ============================================
// FUNCIONES UTILITARIAS PARA LOS EQUIPOS
// ============================================

/**
 * Mostrar una sección que está oculta
 * @param {string} sectionId - ID de la sección a mostrar
 */
function showSection(sectionId) {
    const section = document.getElementById(sectionId);
    if (section) {
        section.classList.remove('hidden');
        console.log(`✅ Sección ${sectionId} mostrada`);
        
        // Animación suave al aparecer
        section.style.opacity = '0';
        section.style.transform = 'translateY(20px)';
        
        setTimeout(() => {
            section.style.transition = 'all 0.5s ease';
            section.style.opacity = '1';
            section.style.transform = 'translateY(0)';
        }, 10);
    } else {
        console.warn(`⚠️ No se encontró la sección ${sectionId}`);
    }
}

/**
 * Ocultar una sección
 * @param {string} sectionId - ID de la sección a ocultar
 */
function hideSection(sectionId) {
    const section = document.getElementById(sectionId);
    if (section) {
        section.classList.add('hidden');
        console.log(`🙈 Sección ${sectionId} ocultada`);
    }
}

/**
 * Mostrar mensaje temporal al usuario
 * @param {string} message - Mensaje a mostrar
 * @param {string} type - Tipo de mensaje (success, error, info, warning)
 */
function showMessage(message, type = 'info') {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message message-${type}`;
    messageDiv.innerHTML = `
        <span class="message-icon">${getMessageIcon(type)}</span>
        <span class="message-text">${message}</span>
    `;
    
    // Estilos del mensaje
    Object.assign(messageDiv.style, {
        position: 'fixed',
        top: '20px',
        right: '20px',
        padding: '1rem 1.5rem',
        backgroundColor: getMessageColor(type),
        color: 'white',
        borderRadius: '8px',
        boxShadow: '0 4px 12px rgba(0,0,0,0.2)',
        zIndex: '9999',
        opacity: '0',
        transform: 'translateX(100%)',
        transition: 'all 0.3s ease'
    });
    
    document.body.appendChild(messageDiv);
    
    // Animación de entrada
    setTimeout(() => {
        messageDiv.style.opacity = '1';
        messageDiv.style.transform = 'translateX(0)';
    }, 10);
    
    // Eliminar después de 4 segundos
    setTimeout(() => {
        messageDiv.style.opacity = '0';
        messageDiv.style.transform = 'translateX(100%)';
        setTimeout(() => {
            if (messageDiv.parentNode) {
                messageDiv.parentNode.removeChild(messageDiv);
            }
        }, 300);
    }, 4000);
}

/**
 * Obtener icono para el tipo de mensaje
 * @param {string} type - Tipo de mensaje
 * @returns {string} Icono correspondiente
 */
function getMessageIcon(type) {
    const icons = {
        success: '✅',
        error: '❌',
        warning: '⚠️',
        info: 'ℹ️'
    };
    return icons[type] || icons.info;
}

/**
 * Obtener color para el tipo de mensaje
 * @param {string} type - Tipo de mensaje
 * @returns {string} Color correspondiente
 */
function getMessageColor(type) {
    const colors = {
        success: '#28a745',
        error: '#dc3545',
        warning: '#ffc107',
        info: '#17a2b8'
    };
    return colors[type] || colors.info;
}

/**
 * Crear efecto ripple en un elemento
 * @param {Event} event - Evento de click
 * @param {Element} element - Elemento donde crear el efecto
 */
function createRippleEffect(event, element) {
    const ripple = document.createElement('span');
    const rect = element.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    const x = event.clientX - rect.left - size / 2;
    const y = event.clientY - rect.top - size / 2;
    
    ripple.style.cssText = `
        position: absolute;
        width: ${size}px;
        height: ${size}px;
        left: ${x}px;
        top: ${y}px;
        background: rgba(255, 255, 255, 0.5);
        border-radius: 50%;
        transform: scale(0);
        animation: ripple 0.6s ease-out;
        pointer-events: none;
    `;
    
    // Agregar animación CSS si no existe
    if (!document.getElementById('ripple-style')) {
        const style = document.createElement('style');
        style.id = 'ripple-style';
        style.textContent = `
            @keyframes ripple {
                to {
                    transform: scale(4);
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(style);
    }
    
    element.style.position = 'relative';
    element.style.overflow = 'hidden';
    element.appendChild(ripple);
    
    setTimeout(() => {
        ripple.remove();
    }, 600);
}

/**
 * Validar formulario básico
 * @param {Element} formElement - Elemento formulario a validar
 * @returns {boolean} Si el formulario es válido
 */
function validateForm(formElement) {
    const inputs = formElement.querySelectorAll('input[required], textarea[required]');
    let isValid = true;
    
    inputs.forEach(input => {
        if (!input.value.trim()) {
            isValid = false;
            input.style.borderColor = '#dc3545';
            input.style.backgroundColor = '#fff5f5';
        } else {
            input.style.borderColor = '';
            input.style.backgroundColor = '';
        }
    });
    
    return isValid;
}

/**
 * Obtener información del dispositivo
 * @returns {Object} Información del dispositivo
 */
function getDeviceInfo() {
    return {
        isMobile: window.innerWidth <= 768,
        isTablet: window.innerWidth > 768 && window.innerWidth <= 1024,
        isDesktop: window.innerWidth > 1024,
        userAgent: navigator.userAgent,
        screenWidth: window.innerWidth,
        screenHeight: window.innerHeight
    };
}

// ============================================
// ÁREA PARA CÓDIGO DE LOS EQUIPOS
// Los estudiantes agregarán sus funciones aquí
// ============================================

/* TEAM 1 - NAVEGACIÓN */
// Funciones de navegación van aquí

/* TEAM 2 - CARACTERÍSTICAS */
// Funciones de la sección features van aquí

/* TEAM 3 - FORMULARIO DE CONTACTO */
// Funciones del formulario van aquí

/* TEAM 4 - GALERÍA */
// Funciones de la galería van aquí

/* TEAM 5 - TESTIMONIOS */
// Funciones de testimonios van aquí

/* TEAM 6 - FOOTER */
// Funciones del footer van aquí

// ============================================
// EVENTOS GLOBALES
// ============================================

// Evento de redimensionamiento de ventana
window.addEventListener('resize', function() {
    const deviceInfo = getDeviceInfo();
    console.log('📱 Dispositivo redimensionado:', deviceInfo);
});

// Evento de scroll para efectos especiales
window.addEventListener('scroll', function() {
    // Los equipos pueden usar este evento para animaciones de scroll
});

// Manejo de errores JavaScript
window.addEventListener('error', function(e) {
    console.error('❌ Error en JavaScript:', e.error);
    showMessage('Se produjo un error. Revisa la consola para más detalles.', 'error');
});

console.log('✅ JavaScript principal cargado correctamente');