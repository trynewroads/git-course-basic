# Changelog

Todas las mejoras y cambios importantes del proyecto se documentan en este archivo.

## [Unreleased]
### Pendiente
- Navegación responsive
- Sección de características
- Formulario de contacto
- Galería de imágenes
- Testimonios de usuarios
- Footer completo

## [0.1.0] - 2024-09-24

### Added
- ✨ Estructura HTML base para sitio colaborativo
- 🎨 Sistema de diseño CSS con variables personalizadas
- ⚡ Funciones utilitarias JavaScript
- 📋 Templates para Pull Requests e Issues
- 📚 Documentación completa para instructores
- 🚀 Configuración inicial del repositorio

### Features
- Diseño responsive mobile-first
- Sistema de mensajes para feedback
- Efectos interactivos en botones
- Smooth scrolling entre secciones
- Validación básica de formularios
- Sistema de componentes CSS

### Technical
- CSS Variables para consistencia de colores
- Utility classes para desarrollo rápido
- JavaScript modular y documentado
- GitHub templates para colaboración
- Estructura de proyecto escalable

---

### Formato de commits
- `feat:` nueva funcionalidad
- `fix:` corrección de bugs
- `docs:` documentación
- `style:` cambios de formato/estilo
- `refactor:` refactorización de código
- `test:` agregar tests