# Ejercicio de Pull Requests - Página Web Colaborativa

Este es un proyecto para practicar Pull Requests trabajando en equipo.

## 🎯 Objetivo
Cada equipo implementará una funcionalidad diferente usando el flujo de trabajo con Pull Requests.

## 🚀 Cómo contribuir
1. Hacer fork del repositorio
2. Crear rama de feature: `git checkout -b feature/nombre-funcionalidad`
3. Implementar los cambios
4. Crear Pull Request
5. Esperar revisión del equipo

## 📋 Funcionalidades disponibles
Ver los Issues para las tareas disponibles:

- **Navegación**: Crear menú de navegación responsive
- **Sección de Características**: Implementar tarjetas con características del producto
- **Formulario de Contacto**: Crear formulario funcional con validación
- **Galería de Imágenes**: Implementar galería con lightbox
- **Testimonios**: Sección de testimonios de usuarios
- **Footer**: Footer completo con links y redes sociales

## 🤝 Colaboradores
Los colaboradores se agregarán automáticamente cuando sus PRs sean aceptados.

## 🔧 Estructura del proyecto
```
ejercicios/
├── index.html          # Página principal
├── css/
│   └── styles.css      # Estilos principales
├── js/
│   └── main.js         # JavaScript principal
├── .github/
│   ├── pull_request_template.md
│   └── ISSUE_TEMPLATE/
└── README.md           # Este archivo
```

## ✅ Criterios de calidad
- Código limpio y comentado
- Responsive design
- Funcionalidad probada
- Sin errores en consola
- Seguir convenciones de nomenclatura