# Proyecto con Git Hooks

Este proyecto demuestra cómo usar Git Hooks nativos.

## Funcionalidad
- Pre-commit: Validar formato de código
- Commit-msg: Validar mensajes de commit
- Pre-push: Ejecutar tests antes de push

