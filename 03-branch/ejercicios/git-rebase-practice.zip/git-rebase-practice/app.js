console.log('Aplicación principal');
