console.log('Aplicación principal');
function maintenanceFunction() {
    console.log('Función de mantenimiento agregada en main');
}
