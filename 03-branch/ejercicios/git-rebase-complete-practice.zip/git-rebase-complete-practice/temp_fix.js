
    // Fix typo in console.log
    addUser(user) {
        this.users.push(user);
        console.log('User successfully added:', user.name);  // Fixed typo
    }
