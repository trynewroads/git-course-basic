class UserManager {
    constructor() {
        this.users = [];
    }
    
    addUser(user) {
        this.users.push(user);
        console.log('User added:', user.name);
    }

    validateEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
}

function login(email, password) {
    if (!validateEmail(email)) {
        return { success: false, message: 'Invalid email format' };
    }
    
    const user = this.users.find(u => u.email === email);
    if (!user) {
        return { success: false, message: 'User not found' };
    }
    
    if (user.password !== password) {
        return { success: false, message: 'Invalid password' };
    }
    
    return { success: true, message: 'Login successful', user: user };
}

    register(name, email, password) {
        if (!this.validateEmail(email)) {
            return { success: false, message: 'Invalid email format' };
        }
        
        if (this.users.find(u => u.email === email)) {
            return { success: false, message: 'User already exists' };
        }
        
        const newUser = { 
            id: Date.now(), 
            name, 
            email, 
            password,
            createdAt: new Date()
        };
        
        this.addUser(newUser);
        return { success: true, message: 'User registered successfully', user: newUser };
    }

    validatePassword(password) {
        if (password.length < 8) {
            return { valid: false, message: 'Password must be at least 8 characters' };
        }
        if (!/[A-Z]/.test(password)) {
            return { valid: false, message: 'Password must contain uppercase letter' };
        }
        if (!/[0-9]/.test(password)) {
            return { valid: false, message: 'Password must contain a number' };
        }
        return { valid: true, message: 'Password is valid' };
    }
