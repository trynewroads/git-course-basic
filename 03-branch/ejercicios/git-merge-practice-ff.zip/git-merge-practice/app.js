console.log('Aplicación principal');
function fastForwardFeature() {
    console.log('Esta es una nueva característica');
    return 'Fast Forward Feature';
}
