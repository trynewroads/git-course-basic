# Proyecto de Práctica - Git Merge
Este proyecto te ayudará a practicar los diferentes tipos de merge en Git.
