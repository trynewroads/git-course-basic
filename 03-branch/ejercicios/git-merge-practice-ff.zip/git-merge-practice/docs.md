// Documentación de fast forward feature
function fastForwardFeature() - Implementa funcionalidad básica
